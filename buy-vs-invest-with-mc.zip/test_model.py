"""Quick sanity tests for the financial engine."""

import math

from model import (Assumptions, StochasticAssumptions, monthly_mortgage_payment,
                   run_model, run_monte_carlo, stamp_duty, summarise)


def test_stamp_duty_standard():
    # £600k standard purchase: 0 + 2500 + 17500 = 20000
    assert math.isclose(stamp_duty(600_000), 20_000, abs_tol=1)


def test_stamp_duty_ftb():
    # First-time buyer £400k: 0 to 300k = 0, 300-400k @5% = 5000
    assert math.isclose(stamp_duty(400_000, first_time_buyer=True), 5_000, abs_tol=1)


def test_stamp_duty_additional():
    # Additional property adds 5% across all bands
    base = stamp_duty(600_000)
    extra = stamp_duty(600_000, additional_property=True)
    assert extra > base + 600_000 * 0.05 - 1


def test_mortgage_payment_zero_rate():
    # £120k over 10y at 0% = £1000/mo
    assert math.isclose(monthly_mortgage_payment(120_000, 0.0, 10), 1_000, abs_tol=1)


def test_mortgage_payment_known():
    # £480k, 4.5%, 30y ≈ £2432.35/mo
    p = monthly_mortgage_payment(480_000, 0.045, 30)
    assert 2_400 < p < 2_460


def test_model_runs_and_grows():
    a = Assumptions()
    df = run_model(a)
    assert len(df) == max(a.horizons) * 12
    # house should appreciate over 30y at 3%
    assert df.iloc[-1]["house_value"] > a.house_price
    # equity should rise as loan amortises
    assert df.iloc[-1]["home_equity"] > df.iloc[0]["home_equity"]
    s = summarise(df, a)
    assert set(s["Horizon (yrs)"]) == set(a.horizons)


if __name__ == "__main__":
    a = Assumptions()
    df = run_model(a)
    print("SDLT:", df.attrs["sdlt"])
    print("Upfront costs:", round(df.attrs["upfront_purchase_costs"]))
    print(summarise(df, a).to_string(index=False))
    print("All assertions...")
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"  PASS {name}")
    print("Done.")


def test_monte_carlo_runs():
    a = StochasticAssumptions()
    pct, wins, buy_out, inv_out = run_monte_carlo(a, n_sims=10)
    assert len(pct) == len(a.horizons)
    assert len(wins) == len(a.horizons)
    assert all(pct["Buy median"] > pct["Buy 10th %ile"])
    assert all(pct["Buy 90th %ile"] > pct["Buy median"])
    assert all(wins["Buy wins (%)"] >= 0) and all(wins["Buy wins (%)"] <= 100)
